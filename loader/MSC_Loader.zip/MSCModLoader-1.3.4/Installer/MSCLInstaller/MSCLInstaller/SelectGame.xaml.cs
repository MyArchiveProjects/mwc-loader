﻿using System.Windows.Controls;

namespace MSCLInstaller
{
    /// <summary>
    /// Interaction logic for SelectGame.xaml
    /// </summary>
    public partial class SelectGame : Page
    {
        public SelectGame()
        {
            InitializeComponent();
        }
    }
}
