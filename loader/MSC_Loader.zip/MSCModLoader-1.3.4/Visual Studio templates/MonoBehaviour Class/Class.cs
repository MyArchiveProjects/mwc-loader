﻿using MSCLoader;
using UnityEngine;

namespace $rootnamespace$
{
    public class $safeitemname$ : MonoBehaviour
    {
    	
        // Use this for initialization
	    void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}