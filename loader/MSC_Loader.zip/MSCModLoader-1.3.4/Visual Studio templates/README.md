# Visual Studio templates

Here are the Visual Studio templates for MSCLoader, in case you want to copy them manually.
